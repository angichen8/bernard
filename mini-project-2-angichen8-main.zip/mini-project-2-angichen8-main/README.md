[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/H7YcSAlt)
# DS105W (2025/2026) - ✍️ Mini Project 2

<!-- Optionally, add an illustrative banner image here to give your project a visual identity -->
<!-- ![](figures/an-illustrative-banner.png) -->

**Author:** [TODO: Name or GitHub Username](https://github.com/<your-github-username>)

This project is part of the [LSE DS105W Winter Term 2025/2026](https://lse-dsi.github.io/DS105/2025-2026/winter-term/course-info.qmd) course and aims to answer the question: **"How does travelling between Inner London and Outer London change when it is done at peak versus off-peak hours?"** with data from the [TfL Journey Planner API](https://api.tfl.gov.uk) and the [ONS Postcode Directory](https://data.london.gov.uk/dataset/postcode-directory-for-london-exp5p/).

[TODO: ...explain _why_ you focused on the locations, time windows, and metrics you chose...].

My answer to the question is: [TODO: ...summarise your conclusion here...]. Check out the [REPORT.md](REPORT.md) to understand how I arrived at this conclusion.


## 📂 Repository Structure

If you decide to clone this project and try to replicate my analysis, you will eventually end up with the following structure:

```output
/
├── notebooks/
│   ├── .env                              # you will have to create this
│   ├── NB01-Data-Collection.ipynb
│   ├── NB02-Data-Transformation.ipynb
│   └── NB03-Exploratory-Data-Analysis.ipynb
├── REPORT.md
├── README.md
└── data/
    ├── raw/
    │   ├── london_postcodes-ons-postcodes-directory-feb22.csv  # you will have to download this
    │   └── *.json
    └── processed/
        └── *.csv
```

## How to Run

1. Register for a TfL API key at [api-portal.tfl.gov.uk](https://api-portal.tfl.gov.uk/)

2. Clone this repository to your local machine

    ```bash
    git clone <github-repo-ssh-url>
    ```

3. Create a `.env` file inside `notebooks/` and add your TfL API key:

    ```text
    API_KEY=your_key_here
    ```

4. Install the additional Python packages if you haven't already:

    ```bash
    pip install [TODO: list packages that require installation]
    ```

5. Download the [ONS Postcode Directory](https://data.london.gov.uk/dataset/postcode-directory-for-london-exp5p/) and save it to the `data/raw/` folder.

6. Run `notebooks/NB01` to collect the data. [TODO: if people need to change any variables in the notebook, explain here]

    This will populate the `data/raw/` folder with the raw JSON data.

7. Run `notebooks/NB02` to recreate the `data/processed/` data. [TODO: specify what data is being created and if people need to change any variables in the notebook, explain here]

8. Browse `notebooks/NB03` to see how I explored the data and generated the insights curated for the [REPORT.md](REPORT.md).

# 📟 Get in touch

If you like my work, get in touch with me on [LinkedIn](https://www.linkedin.com/in/your-profile/) or [GitHub](https://github.com/your-username).
