# DS105W (2025/2026) - ✍️ Mini Project 2

<!-- Optionally, add an illustrative banner image here to give your project a visual identity -->
<!-- ![](figures/an-illustrative-banner.png) -->

**Date:** [TODO: Date of the report]
**Author:** [Angi Chen](https://github.com/angichen8)

This project is part of the [LSE DS105W Winter Term 2025/2026](https://lse-dsi.github.io/DS105/2025-2026/winter-term/course-info.qmd) course and aims to answer the question: **"How does travelling between Inner London and Outer London change when it is done at peak versus off-peak hours?"** with data from the [TfL Journey Planner API](https://api.tfl.gov.uk) and the [ONS Postcode Directory](https://data.london.gov.uk/dataset/postcode-directory-for-london-exp5p/).

## 📌 DECISIONS, DECISIONS, DECISIONS

To answer the question, I made the following choices:

1. **Inner London origin:** [TODO: which postcode and why]
2. **Outer London destination(s):** [TODO: which postcode(s) and why]
3. **Peak definition:** [TODO: time window, days, and source/justification]
4. **Off-peak definition:** [TODO: time window, days, and source/justification]
5. **What you measure:** [TODO: duration, number of transfers, or other metric(s)]
6. **Other:** [TODO: any other decisions about modes of transport, API parameters, how you handled missing or thin responses]

[TODO: Explain why you made these choices above and how they help you answer the question.]

## 🤖 AI usage

[TODO: 1 short paragraph explaining whether you used AI at all and how AI was useful (or not) to you. **Include links to chatlogs that help us see your process.**]

## 🔩 Technical Implementation

[TODO: 1 (or 2 max.) paragraph explaining how you went through the Data Science Workflow as you progressed with your project.]

## 📊 Insights & Visualisations

[TODO: Add your two selected insights inside this section. Add one plot or one stylised table per insight and one accompanying paragraph. Help your reader understand what you found and why it matters. Acknowledge any limitations of the data and the methods you used.]

## 📝 Reflection

[TODO: What did this project allow you to learn? What would you do differently if you were to do it again?]
